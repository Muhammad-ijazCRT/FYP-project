# Real-Time Fingers Counter & Hand Gesture Recognizer


![progress rep 01 (fingers counting model)](https://user-images.githubusercontent.com/75518471/148027187-6c3201e7-bca2-4472-a268-bb492c46a3ef.gif)


