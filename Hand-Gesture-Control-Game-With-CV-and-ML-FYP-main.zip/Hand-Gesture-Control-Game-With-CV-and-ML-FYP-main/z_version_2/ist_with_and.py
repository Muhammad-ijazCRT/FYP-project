test_list = [0,1,1,0,0]

res = [ test_list[1], test_list[2] ]
sec = [ test_list[0], test_list[3], test_list[4] ]

if res ==[1,1] and sec == [0,0,0]:
    print('yes')
else:
    print('No')

# if res == '1' and sec == 0:
#     print('alhamdulillah')